import { HttpInterceptor, HttpRequest, HttpHandler,HttpEvent } from "@angular/common/http";
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/observable';


@Injectable()
export class HeaderInterceptor implements HttpInterceptor {
  
  constructor() {}
 
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
      // Clone the request and set the new header in one step
      let newHeaders = req.headers.append('Accept', 'application/json');
      if (req.method === 'POST') {
        // now modify the newHeaders by appending a further header and re-assign
        newHeaders = newHeaders.append('Content-Type','application/json'); 
      }
      else{
        newHeaders = newHeaders.append('Accept-CH','sai'); 
        alert(newHeaders);
      }
      // clone original request, pass the new headers
      return next.handle(req.clone({headers: newHeaders}));
    
  }
}