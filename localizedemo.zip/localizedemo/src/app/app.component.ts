import { Component } from '@angular/core';
import {HttpModule, RequestOptions} from '@angular/http';

import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'localizedemo';
  minutes = 0;
  constructor(private http: HttpClient) {
    // let header = new HttpHeaders();
    // header.append('Content-Type', 'application/json');
    // header.append('authentication', 'uiiii');
//     let map = new Map();
//     map.set("Chrome", 1);
//     map.set("v", 73);
   
// let headerJson = {
//   'Content-Type': 'application/json',
//   'Accept': 'application/json',
//   'access-token': "sai",
//   'client':"gomathi",
//   'Sec-Fetch-User': "0",
//   "Sec-CH-UA":"chrome"
//   };
//   let headersConfig = new HttpHeaders(headerJson);
//   console.log(headerJson["Sec-CH-UA"]);
    navigator.userAgentData.mobile; 
    navigator.userAgentData.uaList; 
    navigator.userAgentData.getHighEntropyValues([
    "platform",
    "platformVersion",
    "architecture",
    "model",
    "uaFullVersion"
    ]).then(res => console.log(res)); 
    
  }
 
}
