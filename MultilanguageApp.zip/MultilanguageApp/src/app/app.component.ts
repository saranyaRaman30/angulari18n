import {Component} from '@angular/core';
import {TranslateService} from '@ngx-translate/core'; 
@Component({  
  selector: 'app-root',  
  templateUrl: './app.component.html',  
  styleUrls: ['./app.component.css']  
})  
export class AppComponent {  
  constructor(public translate: TranslateService) {
    // translate.addLangs(['en', 'fr']);
    // translate.setDefaultLang('en');

    // const browserLang = translate.getBrowserLang();
    // translate.use(browserLang.match(/fr|FR/) ? 'fr' : 'en');
    
    // console.log('Browser Lang =', browserLang);
    // console.log('Navigator Lang =', navigator.language);
    // console.log('Current Lang =', translate.currentLang);
  
    
  }
  useLanguage(language: string){
    this.translate.use(language);
  }
}