import { Component, OnInit, ViewChild } from '@angular/core';
import {TranslateService} from '@ngx-translate/core'; 

@Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.css']
})
export class SampleComponent implements OnInit {
  @ViewChild('sampletemplateform', {static: false}) formValues;
  eidPattern = "^[a-zA-Z0-9]+$";
  unamePattern = "[a-zA-Z]*";
  mobnumPattern = "^((\\+91-?)|0)?[0-9]{10}$"; 
  emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$';

  model: any = {};
  currentuser="";
  public recievedval: boolean;
  showcomp :boolean = false;
  showform :boolean = true;
  constructor(public translate: TranslateService) { 
    translate.addLangs(['en', 'fr']);
    translate.setDefaultLang('en');

    var url =window.location.href;
    if(url.indexOf("9009")>-1){
      this.translate.use('en');
    }
    else{
      this.translate.use('fr');
    }
    
  }
  

  ngOnInit() {
  }
  onSubmit() {
    this.formValues.resetForm();

  }
  
}
